package Assignment1.redo1;

public interface User {
    String get_email();
    String get_password();
    void set_email(String email);
    void set_password(String password);
}
